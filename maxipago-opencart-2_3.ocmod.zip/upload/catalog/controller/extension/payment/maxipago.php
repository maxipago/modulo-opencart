<?php
/**
 * maxiPago!
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 */

/**
 * maxiPago! Payment Method
 *
 * @package    maxiPago!
 * @author     Bizcommerce
 * @copyright  Copyright (c) 2016 BizCommerce
 *
 * @property ModelExtensionPaymentMaxipago model_extension_payment_maxipago
 * @property ModelCheckoutOrder model_checkout_order
 */
class ControllerExtensionPaymentMaxipago extends Controller
{
    const CC_BRANDS = array('VISA', 'MASTERCARD', 'AMEX', 'DINERS', 'ELO', 'DISCOVER', 'HIPERCARD');
    const EFT_BANKS = array('17' => 'Bradesco', '18' => 'Itaú');

    const MAXIPAGO_CODE = 'maxipago';

    public function __construct($registry)
    {
        parent::__construct($registry);
        $this->registry = $registry;
        $this->language->load('extension/payment/maxipago');
    }

    public function index()
    {
        $data = array();

        $this->load->model('checkout/order');
        $this->load->model('extension/payment/maxipago');

        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
        $data = $this->_translate($data);

        $data['text_title']     = $this->getMethodTitle();
        $data['button_confirm'] = $this->language->get('button_confirm') . ' ' . $data['text_title'];
        $data['cc_enabled']     = $this->config->get('maxipago_cc_enabled');
        $data['ticket_enabled'] = $this->config->get('maxipago_ticket_enabled');
        $data['eft_enabled']     = $this->config->get('maxipago_eft_enabled');


        $data['cards'] = array();
        foreach (self::CC_BRANDS as $brand) {
            if ($this->config->get('maxipago_' . strtolower($brand) . '_processor')) {
                array_push($data['cards'], $brand);
            }
        }

        $data['eft_banks_enabled']  = $this->config->get('maxipago_eft_banks');
        $data['banks'] = self::EFT_BANKS;
        $data['order_info'] = $order_info;
        $canSave = false;
        if (isset($order_info['customer_id']) && $order_info['customer_id']) {
            $canSave = $this->config->get('maxipago_cc_can_save');
        }
        $data['cc_can_save'] = $canSave;

        $data['installments'] = $this->model_extension_payment_maxipago->getInstallments($order_info);
        $data['saved_cards'] = $this->model_extension_payment_maxipago->getSavedCards($canSave, $order_info['customer_id']);

        $base_url = $this->config->get('config_url');
        if (isset($this->request->server['HTTPS']) && (($this->request->server['HTTPS'] == 'on') || ($this->request->server['HTTPS'] == '1'))) {
            $base_url = $this->config->get('config_ssl');
        }
        $data['base_url'] = $base_url;

        /* Link */
        $data['continue'] = $this->url->link('checkout/success', '', true);

        $this->session->data['maxipago_data'] = $data;

        return $this->load->view('extension/payment/maxipago', $data);
    }

    /**
     * Method that creates a transaction
     */
    public function transaction()
    {
        $response = array();
        $response['error'] = false;

        try {
            /* ID do Pedido */
            $order_id = $this->session->data['order_id'];

            $this->load->model('checkout/order');
            $this->load->model('extension/payment/maxipago');

            /* Informações do Pedido */
            $order_info = $this->model_checkout_order->getOrder($order_id);

            $type = isset($this->request->post['maxipago_type']) ? $this->request->post['maxipago_type'] : null;

            if ($type == 'cc') {
                $response = $this->model_extension_payment_maxipago->cardMethod($order_info);
            } else if ($type == 'ticket') {
                $response = $this->model_extension_payment_maxipago->ticketMethod($order_info);
            } else if ($type == 'eft') {
                $eftBank = $this->request->post['eft_bank'];
                $response = $this->model_extension_payment_maxipago->eftMethod($order_info);
            }

        } catch (Exception $e) {
            $response['error'] = true;
            $response['message'] = $e->getMessage();
        }

        if (is_array($response) || is_object($response)) {
            $response = json_encode($response);
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput($response);
    }

    /**
     * Delete saved Credit Card in maxiPago!
     */
    public function delete()
    {
        try {
            $this->load->model('checkout/order');
            $this->load->model('extension/payment/maxipago');

            $response = array('success' => false, 'message' => '');
            $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
            $id_customer = $order_info['customer_id'];

            if ($id_customer) {
                $description = $this->request->post['ident'];
                $sql = 'SELECT *
                        FROM ' . DB_PREFIX . 'maxipago_cc_token
                        WHERE `id_customer` = \'' . $id_customer . '\'
                        AND `description` = \'' . $description . '\'
                        LIMIT 1; ';
                $ccSaved = $this->db->query($sql)->row;

                if ($this->model_extension_payment_maxipago->deleteCC($ccSaved)) {
                    $response = array('success' => true);
                }
            }
        } catch (Exception $e) {
            $response['success'] = false;
            $response['message'] = $e->getMessage();
        }

        if (is_array($response) || is_object($response)) {
            $response = json_encode($response);
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput($response);
    }

    /**
     * Method that confirms the payment and create a comment with the payment information
     */
    public function confirm()
    {
        if ($this->session->data['payment_method']['code'] == 'maxipago') {

            $this->load->model('extension/payment/maxipago');
            $this->model_extension_payment_maxipago->confirmPayment();

        }
    }

    /**
     * @param $route
     * @param $orders
     */
    public function change($route, $data = array())
    {
        $this->load->model('extension/payment/maxipago');
        $this->load->language('extension/payment/maxipago');
        $this->load->model('checkout/order');

        $order_id = $this->model_extension_payment_maxipago->getRequest('order_id');
        $order_status_id = $this->model_extension_payment_maxipago->getPost('order_status_id');

        if ($order_id && $order_status_id) {
            $order_info = $this->model_checkout_order->getOrder($order_id);

            //If payment method is equal to maxipago and the status is changed
            if (
                $order_info['payment_code'] == self::MAXIPAGO_CODE
                && $order_info['order_status_id'] != $order_status_id
            ) {
                if (
                    $this->config->get('maxipago_cc_order_reverse')
                    && $order_status_id == $this->config->get('maxipago_order_cancelled')
                    && $this->config->get('maxipago_order_cancelled') != $this->config->get('maxipago_order_approved')
                    && $this->config->get('maxipago_order_cancelled') != $this->config->get('maxipago_order_processing')
                ) {
                    //If the order uses maxiPago! and status equals cancelled
                    $this->model_extension_payment_maxipago->reversePayment($order_info);
                } else if (
                    $order_status_id == $this->config->get('maxipago_order_refunded')
                    && $this->config->get('maxipago_order_refunded') != $this->config->get('maxipago_order_approved')
                    && $this->config->get('maxipago_order_refunded') != $this->config->get('maxipago_order_processing')
                ) {
                    //If the order uses maxiPago! and status equals approved
                    $this->model_extension_payment_maxipago->reversePayment($order_info);
                } else if (
                    $order_status_id == $this->config->get('maxipago_order_approved')
                    && $this->config->get('maxipago_order_approved') != $this->config->get('maxipago_order_cancelled')
                    && $this->config->get('maxipago_order_approved') != $this->config->get('maxipago_order_processing')
                ) {
                    //If the order uses maxiPago! and status equals approved
                    $this->model_extension_payment_maxipago->capturePayment($order_info, $order_status_id);
                }
            }
        }
    }

    protected function getMethodTitle()
    {
        return ($this->config->get('maxipago_method_title')) ? $this->config->get('maxipago_method_title') : $this->language->get('text_title');
    }

    protected function _translate($data)
    {
        $textFields = array(
            'button_sending_text',
            'error_transaction',
            'error_already_processed',
            'error_cc_brand',
            'error_cc_number',
            'error_cc_owner',
            'error_cc_cvv2',
            'error_eft_bank',
            'error_cpf',

            'entry_select',
            'entry_cpf_number',
            'entry_cc_owner',
            'entry_cc_type',
            'entry_cc_number',
            'entry_cc_expire_date',
            'entry_cc_cvv',
            'entry_cc_cvv2',
            'entry_use_saved_card',
            'entry_save_card',
            'entry_installments',
            'entry_per_month',
            'entry_without_interest',
            'entry_total',
            'entry_remove_card',

            'entry_ticket_instructions',
            'entry_eft_bank',

            'ticket_text',
            'cc_text',
            'eft_text',
        );

        foreach ($textFields as $field) {
            $data[$field] = $this->language->get($field);
        }

        $data['months'] = array();

        for ($i = 1; $i <= 12; $i++) {
            $data['months'][] = array(
                'text'  => strftime('%B', mktime(0, 0, 0, $i, 1, 2000)),
                'value' => sprintf('%02d', $i)
            );
        }

        $today = getdate();
        $data['year_expire'] = array();

        for ($i = $today['year']; $i < $today['year'] + 11; $i++) {
            $data['year_expire'][] = array(
                'text'  => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)),
                'value' => strftime('%Y', mktime(0, 0, 0, 1, 1, $i))
            );
        }

        return $data;
    }
}
