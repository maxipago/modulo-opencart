<?php
/**
 * maxiPago!
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 */

/**
 * maxiPago! Payment Method
 *
 * @package    maxiPago!
 * @author     Bizcommerce
 * @copyright  Copyright (c) 2016 BizCommerce
 *
 * @property ModelCheckoutOrder model_checkout_order
 */

require_once(DIR_SYSTEM . 'library/maxipago/maxipago.php');
class ModelPaymentMaxipago extends Model
{
    protected $_maxipago;
    const MAXIPAGO_CODE = 'maxipago';

    protected $_responseCodes = array(
        '0' => 'Pagamento Aprovado',
        '1' => 'Pagamento Reprovado',
        '2' => 'Pagamento Reprovado',
        '5' => 'Pagamento em análise',
        '1022' => 'Ocorreu um erro com a finalizadora, entre em contato com nossa equipe',
        '1024' => 'Erros, dados enviados inválidos, entre em contato com nossa equipe',
        '1025' => 'Erro nas credenciais de envio, entre em contato com nossa equipe',
        '2048' => 'Erro interno, entre em contato com nossa equipe',
        '4097' => 'Erro de tempo de execução, entre em contato com nossa equipe'
    );

    protected $_transactionStates = array(
        '1' => 'In Progress',
        '3' => 'Captured',
        '6' => 'Authorized',
        '7' => 'Declined',
        '9' => 'Voided',
        '10' => 'Paid',
        '22' => 'Boleto Issued',
        '34' => 'Boleto Viewed',
        '35' => 'Boleto Underpaid',
        '36' => 'Boleto Overpaid',

        '4' => 'Pending Capture',
        '5' => 'Pending Authorization',
        '8' => 'Reversed',
        '11' => 'Pending Confirmation',
        '12' => 'Pending Review (check with Support)',
        '13' => 'Pending Reversion',
        '14' => 'Pending Capture (retrial)',
        '16' => 'Pending Reversal',
        '18' => 'Pending Void',
        '19' => 'Pending Void (retrial)',
        '29' => 'Pending Authentication',
        '30' => 'Authenticated',
        '31' => 'Pending Reversal (retrial)',
        '32' => 'Authentication in progress',
        '33' => 'Submitted Authentication',
        '38' => 'File submission pending Reversal',
        '44' => 'Fraud Approved',
        '45' => 'Fraud Declined',
        '46' => 'Fraud Review'
    );

    /**
     * maxiPago! lib Object
     * @return MaxiPago
     */
    public function getMaxipago()
    {
        if (!$this->_maxipago) {
            $merchantId = $this->config->get('maxipago_store_id');
            $sellerKey = $this->config->get('maxipago_consumer_key');
            if ($merchantId && $sellerKey) {
                $environment = ($this->config->get('maxipago_environment') == 'test') ? 'TEST' : 'LIVE';
                $this->_maxipago = new MaxiPago();
                $this->_maxipago->setCredentials($merchantId, $sellerKey);
                $this->_maxipago->setEnvironment($environment);
            }
        }

        return $this->_maxipago;

    }

    public function getMethod($address, $total)
    {
        $this->load->language('payment/maxipago');

        $query = $this->db->query("
          SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone 
          WHERE geo_zone_id = '" . (int)$this->config->get('maxipago_geo_zone_id') . "' 
          AND country_id = '" . (int)$address['country_id'] . "' 
          AND (
            zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0'
          )"
        );

        if ($this->config->get('maxipago_maximum_amount') > 0 && $this->config->get('maxipago_maximum_amount') <= $total) {
            $status = false;
        } elseif ($this->config->get('maxipago_minimum_amount') > 0 && $this->config->get('maxipago_minimum_amount') > $total) {
            $status = false;
        } elseif (!$this->config->get('maxipago_geo_zone_id')) {
            $status = true;
        } elseif ($query->num_rows) {
            $status = true;
        } else {
            $status = false;
        }

        $method_data = array();
        if ($status) {
            $method_data = array(
                'code' => self::MAXIPAGO_CODE,
                'title' => ($this->config->get(self::MAXIPAGO_CODE . '_method_title')) ? $this->config->get(self::MAXIPAGO_CODE . '_method_title') : $this->language->get('text_title'),
                'terms' => '',
                'sort_order' => $this->config->get('maxipago_sort_order')
            );
        }

        return $method_data;
    }

    /**
     * Remove the Credit Card frm maxiPago! Account and remove from the store Account
     *
     * @param $ccSaved
     * @return bool
     */
    public function deleteCC($ccSaved)
    {
        try {
            $data = array(
                'command' => 'delete-card-onfile',
                'customerId' => $ccSaved['id_customer'],
                'token' => $ccSaved['token']
            );

            $this->getMaxipago()->deleteCreditCard($data);
            $response = $this->getMaxipago()->response;
            $this->_saveTransaction('remove_card', $data, $response, null, false);

            $sql = 'DELETE FROM `' . DB_PREFIX . 'maxipago_cc_token` WHERE `id` = \'' . $ccSaved['id'] . '\';';
            $this->db->query($sql);
        } catch (Exception $e) {
            return false;
        }

        return true;
    }

    /**
     * Send the ticket Payment method do maxiPago!
     *
     * @param $order_info
     * @return boolean
     */
    public function ticketMethod($order_info)
    {
        //Language
        $this->language->load('payment/maxipago');
        $response = null;

        //Boleto
        $methodEnabled = $this->config->get('maxipago_ticket_enabled');
        if ($methodEnabled) {

            //Order Data
            $totalOrder = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);

            $orderId   = $this->session->data['order_id'];
            $ipAddress = $order_info['ip'];
            $address = $this->_getAddress($order_info);

            $environment = $this->config->get('maxipago_environment');

            $dayToExpire = (int) $this->config->get('maxipago_ticket_days_to_expire');
            $instructions = $this->config->get('maxipago_ticket_instructions');

            $date = new DateTime();
            $date->modify('+' . $dayToExpire . ' days');
            $expirationDate = $date->format('Y-m-d');

            $boletoBank = ($environment == 'test') ? 12 : $this->config->get('maxipago_ticket_bank');

            $data = array(
                'referenceNum' => $orderId, //Order ID
                'processorID' => $boletoBank, //Bank Number
                'ipAddress' => $ipAddress,
                'chargeTotal' => $totalOrder,
                'expirationDate' => $expirationDate,
                'number' => $orderId, //Our Number
                'instructions' => $instructions, //Instructions
                'bname' => $order_info['firstname'] . ' ' . $order_info['lastname'],
                'baddress' => $address['address1'],
                'baddress2' => $address['address2'],
                'bcity' => $address['city'],
                'bstate' => $address['state'],
                'bpostalcode' => $address['postcode'],
                'bcountry' => $address['country'],
                'bemail' => $order_info['email'],
            );

            $this->getMaxipago()->boletoSale($data);
            $response = $this->getMaxipago()->response;

            $this->log($this->getMaxipago()->xmlRequest);
            $this->log($this->getMaxipago()->xmlResponse);

            $boletoUrl = isset($response['boletoUrl']) ? $response['boletoUrl'] : null;
            $this->_saveTransaction('ticket', $data, $response, $boletoUrl);

        }
        return $response;

    }

    /**
     * Send the payment method Credit Card to maxiPago!
     *
     * @param $order_info
     * @return boolean
     */
    public function cardMethod($order_info)
    {
        $methodEnabled = $this->config->get('maxipago_cc_enabled');
        $response = null;

        if ($methodEnabled) {

            //Order Data
            $totalOrder = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);
            $order_id = $this->session->data['order_id'];

            $softDescriptor = $this->config->get('maxipago_cc_soft_descriptor');
            $processingType = $this->config->get('maxipago_cc_processing_type'); //auth || sale

            $fraudCheck = ($this->config->get('maxipago_cc_fraud_check')) ? 'Y' : 'N';
            $fraudCheck = $processingType != 'sale' ? $fraudCheck : 'N';

            $maxWithoutInterest = (int) $this->config->get('maxipago_cc_installments_without_interest');
            $interestRate = $this->config->get('maxipago_cc_interest_rate');
            $hasInterest = 'N';

            $customerId = $order_info['customer_id'];

            $ccBrand = $this->getPost('cc_brand');
            $ccNumber = $this->getPost('cc_number');
            $ccOwner = $this->getPost('cc_owner');
            $ccExpMonth = $this->getPost('cc_expire_date_month');
            $ccExpYear = $this->getPost('cc_expire_date_year');
            $ccCvv2 = $this->getPost('cc_cvv2');
            $ccInstallments = $this->getPost('cc_installments');

            $ipAddress = isset($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : null;

            if ($interestRate && $ccInstallments > $maxWithoutInterest) {
                $hasInterest = 'Y';
                $totalOrder = $this->getTotalByInstallments($totalOrder, $ccInstallments, $interestRate);
            }

            $ccSavedCard = $this->getPost('cc_saved_card');

            if ($ccSavedCard) {
                $ccCvvSaved = $this->getPost('cc_cvv2_saved');

                $sql = 'SELECT *
                        FROM ' . DB_PREFIX . 'maxipago_cc_token
                        WHERE `id_customer` = \'' . $customerId . '\'
                        AND `description` = \'' . $ccSavedCard . '\'
                        LIMIT 1; ';
                $maxipagoToken = $this->db->query($sql)->row;

                $processorID =  $this->config->get('maxipago_' . $maxipagoToken['brand'] . '_processor');

                $data = array(
                    'customerId' => $maxipagoToken['id_customer_maxipago'],
                    'token' => $maxipagoToken['token'],
                    'cvvNumber' => $ccCvvSaved,
                    'referenceNum' => $order_id, //Order ID
                    'processorID' => $processorID, //Processor
                    'ipAddress' => $ipAddress,
                    'fraudCheck' => 'N',
                    'currencyCode' => $order_info['currency_code'],
                    'chargeTotal' => $totalOrder,
                    'numberOfInstallments' => $ccInstallments,
                    'chargeInterest' => $hasInterest
                );

            } else {

                $processorID =  $this->config->get('maxipago_' . $ccBrand . '_processor');

                $data = array(
                    'referenceNum' => $order_id, //Order ID
                    'processorID' => $processorID, //Processor
                    'ipAddress' => $ipAddress,
                    'fraudCheck' => $fraudCheck,
                    'number' => $ccNumber,
                    'expMonth' => $ccExpMonth,
                    'expYear' => $ccExpYear,
                    'cvvNumber' => $ccCvv2,
                    'currencyCode' => $order_info['currency_code'],
                    'chargeTotal' => $totalOrder,
                    'numberOfInstallments' => $ccInstallments,
                    'chargeInterest' => $hasInterest
                );

                $ccSaveCard = $this->getPost('cc_save_card');
                if ($ccSaveCard) {
                    $this->saveCard($order_info);
                }
            }

            if ($processingType == 'auth') {
                $this->getMaxipago()->creditCardAuth($data);
            } else {
                $this->getMaxipago()->creditCardSale($data);
            }

            $response = $this->getMaxipago()->response;

            $this->log($this->getMaxipago()->xmlRequest);
            $this->log($this->getMaxipago()->xmlResponse);

            $this->_saveTransaction('card', $data, $response);

        }
        return $response;

    }

    /**
     * Send the payment method EFT to maxiPago!
     *
     * @param $order_info
     * @return boolean
     */
    public function eftMethod($order_info)
    {
        $response = null;
        $methodEnabled = $this->config->get('maxipago_eft_enabled');

        if ($methodEnabled) {

            //Order Data
            $totalOrder = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);

            $order_id = $this->session->data['order_id'];
            $customerId = $order_info['customer_id'];
            $firstname = $order_info['firstname'];
            $lastname = $order_info['lastname'];

            $environment = $this->config->get('maxipago_environment');

            $tefBank = ($environment == 'test') ? 17 : $this->getPost('eft_bank');
            $cpf = $this->getPost('cpf');
            $ipAddress = isset($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : null;

            $address = $this->_getAddress($order_info);

            $data = array(
                'referenceNum' => $order_id, //Order ID
                'processorID' => $tefBank, //Bank Number
                'ipAddress' => $ipAddress,
                'chargeTotal' => $totalOrder,
                'customerIdExt' => $cpf,
                'name' => $firstname . ' ' . $lastname,
                'address' => $address['address1'], //Address 1
                'address2' => $address['address2'], //Address 2
                'city' => $address['city'],
                'state' => $address['state'],
                'postalcode' => $address['postcode'],
                'country' => $address['country'],
                'parametersURL' => 'oid=' . $order_id
            );

            $this->getMaxipago()->onlineDebitSale($data);
            $response = $this->getMaxipago()->response;

            $this->log($this->getMaxipago()->xmlRequest);
            $this->log($this->getMaxipago()->xmlResponse);

            $onlineDebitUrl = isset($response['onlineDebitUrl']) ? $response['onlineDebitUrl'] : null;
            $this->_saveTransaction('eft', $data, $response, $onlineDebitUrl);

        }

        return $response;

    }

    /**
     * Save the credit card at the database
     * @param $order_info
     * @return null
     */
    public function saveCard($order_info)
    {
        try {
            $this->load->language('payment/maxipago');

            $address = $this->_getAddress($order_info);

            $customerId = $order_info['customer_id'];
            $firstname = $order_info['firstname'];
            $lastname = $order_info['lastname'];
            $mpCustomerId = null;

            $ccBrand = $this->getPost('cc_brand');
            $ccNumber = $this->getPost('cc_number');
            $ccExpMonth = $this->getPost('cc_expire_date_month');
            $ccExpYear = $this->getPost('cc_expire_date_year');

            $sql = 'SELECT *
                FROM ' . DB_PREFIX . 'maxipago_cc_token
                WHERE `id_customer` = \'' . $customerId . '\'
                LIMIT 1';
            $mpCustomer = $this->db->query($sql)->row;

            if (!$mpCustomer) {
                $customerData = array(
                    'customerIdExt' => $customerId,
                    'firstName' => $firstname,
                    'lastName' => $lastname
                );
                $this->getMaxipago()->addProfile($customerData);
                $response = $this->getMaxipago()->response;

                $this->_saveTransaction('add_profile', $customerData, $response, null, false);
                if (isset($response['errorCode']) && $response['errorCode'] == 1) {

                    //Search the table to see if the profile already exists
                    $sql = 'SELECT *
                            FROM ' . DB_PREFIX . 'maxipago_transactions
                            WHERE `method` = \'add_profile\';
                        ';

                    $query = $this->db->query($sql);

                    if ($query->num_rows) {
                        foreach ($query->rows as $row) {
                            $requestRow = json_decode($row['request']);
                            if (property_exists($requestRow, 'customerIdExt') && $requestRow->customerIdExt == $customerId) {
                                $responseRow = json_decode($row['return']);
                                if (property_exists($responseRow, 'result') && property_exists($responseRow->result, 'customerId')) {
                                    $mpCustomerId = $responseRow->result->customerId;
                                }
                            }
                        }
                    }
                } else {
                    $mpCustomerId = $this->getMaxipago()->getCustomerId();
                }

            } else {
                $mpCustomerId = $mpCustomer['id_customer_maxipago'];
            }

            if ($mpCustomerId) {
                $date = new DateTime($ccExpYear . '-' . $ccExpMonth . '-01');
                $date->modify('+1 month');
                $endDate = $date->format('m/d/Y');

                $ccData = array(
                    'customerId' => $mpCustomerId,
                    'creditCardNumber' => $ccNumber,
                    'expirationMonth' => $ccExpMonth,
                    'expirationYear' => $ccExpYear,
                    'billingName' => $firstname . ' ' . $lastname,
                    'billingAddress1' => $address['address1'],
                    'billingAddress2' => $address['address2'],
                    'billingCity' => $address['city'],
                    'billingState' => $address['state'],
                    'billingZip' => $address['postcode'],
                    'billingPhone' => $address['phone'],
                    'billingEmail' => $order_info['email'],
                    'onFileEndDate' => $endDate,
                    'onFilePermissions' => 'ongoing',
                );

                $this->getMaxipago()->addCreditCard($ccData);
                $token = $this->getMaxipago()->getToken();
                $this->_saveTransaction('save_card', $ccData, $this->getMaxipago()->response, null, false);

                if ($token) {
                    $ccEnc = substr($ccNumber, 0, 6) . 'XXXXXX' . substr($ccNumber, -4, 4);
                    $sql = 'INSERT INTO `' . DB_PREFIX . 'maxipago_cc_token` 
                                (`id_customer`, `id_customer_maxipago`, `brand`, `token`, `description`)
                            VALUES
                                ("' . $customerId . '", "' . $mpCustomerId . '", "' . $ccBrand . '", "' . $token . '", "' . $ccEnc . '" )
                            ';

                    $this->db->query($sql);
                }
            }
        } catch (Exception $e) {
            return false;
        }

        return true;
    }

    /**
     * Controller that confirms the payment
     */
    public function confirmPayment()
    {
        $this->load->model('checkout/order');

        $paymentType = $this->getPost('type');
        $responseCode = $this->getPost('responseCode');
        $responseMessage = $this->getPost('responseMessage');

        $message = '';

        switch ($responseCode) {
            //Aprovada
            case '0':

                $status = $this->config->get('maxipago_order_processing');
                if ($paymentType == 'eft') {

                    $url = $this->getPost('onlineDebitUrl');
                    $link = '<p><a href="' . $url . '" target="_blank">' . $this->language->get('eft_link_text') . '</a></p>';
                    $message = $this->language->get('order_eft_text') . $link;

                } else if ($paymentType == 'ticket') {

                    //Gera o link do boleto da maxiPago! e coloca nos comentários do pedido
                    $url = $this->getPost('boletoUrl');
                    $link = '<p><a href="' . $url . '" target="_blank">' . $this->language->get('ticket_link_text') . '</a></p>';
                    $message = $this->language->get('order_ticket_text') . $link;

                } else {

                    $message = '<p>' . $this->language->get('order_cc_text') . ' ' . $responseMessage . '</p>';

                    if ($responseMessage == 'CAPTURED') {
                        $status = $this->config->get('maxipago_order_approved');
                    } else if ($responseMessage == 'AUTHORIZED') {
                        $status = $this->config->get('maxipago_order_authorized');
                    }

                    if ($this->getPost('installments')) {
                        $installments = $this->getPost('installments');
                        $total = $this->getPost('total');
                        $totalFormatted =  $this->currency->format($total, $this->session->data['currency']);
                        $installmentsValue = $this->currency->format(($total / $installments), $this->session->data['currency']);
                        $message .= '<p>Total: ' . $totalFormatted . ' - ' . $installments . 'x de ' . $installmentsValue . '</p>';
                    }

                }

                if ($this->getPost('orderID')) {
                    $message .= '<p>orderID: ' . $this->getPost('orderID') . '</p>';
                }

                if ($this->getPost('transactionID')) {
                    $message .= '<p>transactionID: ' . $this->getPost('transactionID') . '</p>';
                }

                if ($this->getPost('authCode')) {
                    $message .= '<p>authCode: ' . $this->getPost('authCode') . '</p>';
                }

                break;

            //Cancelado
            case '1':
            case '2':
                $status = $this->config->get('maxipago_order_cancelled');
                $message = $this->language->get('maxipago_order_cancelled');
                break;
            //Erro na transação
            default:
                $status = $this->config->get('maxipago_order_cancelled');
                $message = ($responseCode && isset($this->_responseCodes[$responseCode])) ? $this->_responseCodes[$responseCode] : $this->language->get('order_error');

                if ($this->getPost('errorMessage')) {
                    $message .= '<p>transactionID: ' . $this->getPost('errorMessage') . '</p>';
                }
        }

        $this->model_checkout_order->addOrderHistory($this->session->data['order_id'], $status, $message, true);
    }

    /**
     * @param $order_info
     */
    public function capturePayment($order_info, $order_status_id)
    {
        try {
            $order_id = $order_info['order_id'];
            $sql = 'SELECT *
                    FROM ' . DB_PREFIX . 'maxipago_transactions
                    WHERE `id_order` = "' . $order_id . '"
                    AND `method` = "card";';

            $transaction = $this->db->query($sql)->row;

            if (!empty($transaction) && $transaction['response_message'] != 'CAPTURED') {

                $request = json_decode($transaction['request']);
                $response = json_decode($transaction['return']);

                $data = array(
                    'orderID' => $response->orderID,
                    'referenceNum' => $response->referenceNum,
                    'chargeTotal' => $request->chargeTotal,
                );
                $this->getMaxipago()->creditCardCapture($data);
                $this->_saveTransaction('capture', $data, $this->getMaxipago()->response, null, false);
                $this->_updateTransactionState($order_id);

                return true;
            }

        } catch (Exception $e) {
            $this->log('Error capturing order ' . $order_id . ': ' . $e->getMessage());
        }
        return false;
    }

    /**
     * Refund an order
     * @param $order_info
     * @return bool
     */
    public function reversePayment($order_info)
    {
        try {
            $order_id = $order_info['order_id'];
            $sql = 'SELECT *
                    FROM ' . DB_PREFIX . 'maxipago_transactions
                    WHERE `id_order` = "' . $order_id . '"
                    AND `method` = "card";';

            $transaction = $this->db->query($sql)->row;

            if (!empty($transaction)) {

                $request = json_decode($transaction['request']);
                $response = json_decode($transaction['return']);

                $data = array(
                    'orderID' => $response->orderID,
                    'referenceNum' => $response->referenceNum,
                    'chargeTotal' => $request->chargeTotal,
                );

                $this->getMaxipago()->creditCardRefund($data);
                $this->_saveTransaction('refund', $data, $this->getMaxipago()->response, null, false);
                $this->_updateTransactionState($order_id);

                return true;
            }

        } catch (Exception $e) {
            $this->log('Error refunding order ' . $order_id . ': ' . $e->getMessage());
        }

        return false;
    }

    /**
     * @param $order_info
     * @return array
     * Customer Address
     */
    protected function _getAddress($order_info)
    {
        //Payment Address
        $country = ($order_info['payment_iso_code_2'] != 'BR') ? $order_info['payment_iso_code_2'] : 'Brasil';
        $postcode = preg_replace('/[^0-9]/', '', $order_info['payment_postcode']);
        $postcode = substr($postcode, 0, 5) . '-' . substr($postcode, 5, 3);

        //Payment Number (custom field)
        $number_field = $dob_filed = $this->config->get('maxipago_street_number');
        $payment_number = $order_info['payment_custom_field'][$number_field];
        //Payment Complement (custom field)
        $complement_field = $dob_filed = $this->config->get('maxipago_street_complement');
        $payment_complement = $order_info['payment_custom_field'][$complement_field];

        //Telephone
        $telephone = preg_replace('/[^0-9]/', '', $order_info['telephone']);

        return array(
            'address1' => $order_info['payment_address_1'] . ' ' . $payment_number . ' ' . $payment_complement,
            'address2' => $order_info['payment_address_2'],
            'state' => $order_info['payment_zone_code'],
            'city' => $order_info['payment_city'],
            'postcode' => $postcode,
            'country' => $country,
            'phone' => $telephone,
        );
    }

    /**
     * Update Transaction State to maxipago tables
     * @param $id_order
     * @param array $return
     * @param array $response
     * @return void
     */
    protected function _updateTransactionState($id_order, $return = array(), $response = array())
    {
        $this->load->language('payment/maxipago');
        $this->load->model('payment/maxipago');

        if (empty($return) ) {
            $sql = 'SELECT *
                        FROM ' . DB_PREFIX . 'maxipago_transactions
                        WHERE `id_order` = "' . $id_order . '" 
                        ';
            $transaction = $this->db->query($sql)->row;
            if (!empty($transaction)) {

                $return = json_decode($transaction['return']);

                $search = array(
                    'orderID' => $return->orderID
                );

                $this->getMaxipago()->pullReport($search);
                $response = $this->getMaxipago()->getReportResult();

                if (! empty($response) ) {
                    $responseCode = isset($response[0]['responseCode']) ? $response[0]['responseCode'] : $return->responseCode;
                    if (! property_exists($return, 'originalResponseCode')) {
                        $return->originalResponseCode = $return->responseCode;
                    }
                    $return->responseCode = $responseCode;

                    if (! property_exists($return, 'originalResponseMessage')) {
                        $return->originalResponseMessage = $return->responseMessage;
                    }
                    $state = isset($response[0]['transactionState']) ? $response[0]['transactionState'] : null;
                    $responseMessage = (array_key_exists($state, $this->_transactionStates)) ? $this->_transactionStates[$state] : $return->responseMessage;
                    $return->responseMessage = $responseMessage;
                    $return->transactionState = $state;
                    $transaction['response_message'] = $responseMessage;

                    $sql = 'UPDATE ' . DB_PREFIX . 'maxipago_transactions 
                               SET `response_message` = \'' . strtoupper($responseMessage) . '\',
                                   `return` = \'' . json_encode($return) . '\'
                             WHERE `id_order` = "' . $id_order . '";
                            ';

                    $this->db->query($sql);

                }

            }
        }


    }

    /**
     * Save at the DB the data of the transaction and the Boleto URL when the payment is made with boleto
     *
     * @param $method
     * @param $request
     * @param $return
     * @param null $transactionUrl
     * @param boolean $hasOrder
     */
    protected function _saveTransaction($method, $request, $return, $transactionUrl = null, $hasOrder = true)
    {
        $onlineDebitUrl = null;
        $boletoUrl = null;

        if ($transactionUrl) {
            if ($method == 'eft') {
                $onlineDebitUrl = $transactionUrl;
            } else if ($method == 'ticket') {
                $boletoUrl = $transactionUrl;
            }
        }

        if (is_object($request) || is_array($request)) {

            if (isset($request['number'])) {
                $request['number'] = substr($request['number'], 0, 6) . 'XXXXXX' . substr($request['number'], -4, 4);
            }

            if ($this->getPost('cc_brand')) {
                $request['brand'] = $this->getPost('cc_brand');
            }

            $request = json_encode($request);
        }

        $responseMessage = null;
        if (is_object($return) || is_array($return)) {
            $responseMessage = isset($return['responseMessage']) ? $return['responseMessage'] : null;
            $return = json_encode($return);
        }

        $order_id = isset($this->session->data['order_id']) ? $this->session->data['order_id'] : 0;
        if (! $hasOrder) {
            $order_id = 0;
        }

        $request = $this->db->escape($request);
        $return = $this->db->escape($return);
        $responseMessage = $this->db->escape($responseMessage);

        $sql = 'INSERT INTO `' . DB_PREFIX . 'maxipago_transactions` 
                    (`id_order`, `boleto_url`, `online_debit_url`, `method`, `request`, `return`, `response_message`)
                VALUES
                    ("' . $order_id . '", "' . $boletoUrl . '",  "' . $onlineDebitUrl . '", "' . $method . '" ,"' . $request . '", "' . $return . '", "' . $responseMessage . '" )
                ';

        $this->db->query($sql);
    }

    /**
     * Calculate the installments price for maxiPago!
     * @param $price
     * @param $installments
     * @param $interestRate
     * @return float
     */
    public function getInstallmentPrice($price, $installments, $interestRate)
    {
        $price = (float) $price;
        if ($interestRate) {
            $interestRate = (float)(str_replace(',', '.', $interestRate)) / 100;
            $type = $this->config->get('maxipago_cc_interest_type');
            $valorParcela = 0;
            switch ($type) {
                case 'price':
                    $value = round($price * (($interestRate * pow((1 + $interestRate), $installments)) / (pow((1 + $interestRate), $installments) - 1)), 2);
                    break;
                case 'compound':
                    //M = C * (1 + i)^n
                    $value = ($price * pow(1 + $interestRate, $installments)) / $installments;
                    break;
                case 'simple':
                    //M = C * ( 1 + ( i * n ) )
                    $value = ($price * (1 + ($installments * $interestRate))) / $installments;
            }
        } else {
            if ($installments)
                $value = $price / $installments;
        }
        return $value;
    }

    /**
     * Calculate the total of the order based on interest rate and installmentes
     * @param $price
     * @param $installments
     * @param $interestRate
     * @return float
     */
    public function getTotalByInstallments($price, $installments, $interestRate)
    {
        $installmentPrice = $this->getInstallmentPrice($price, $installments, $interestRate);
        return $installmentPrice * $installments;
    }

    /**
     * Get MAX installments for a price
     * @param null $price
     * @return array|bool
     */
    public function getInstallment($price = null)
    {
        $price = (float) $price;

        $maxInstallments = $this->config->get('maxipago_cc_max_installments');//
        $installmentsWithoutInterest = $this->config->get('maxipago_cc_installments_without_interest');
        $minimumPerInstallment = $this->config->get('maxipago_cc_min_per_installments');
        $minimumPerInstallment = (float)$minimumPerInstallment;

        if ($minimumPerInstallment > 0) {
            if ($minimumPerInstallment > $price / 2)
                return false;

            while ($maxInstallments > ($price / $minimumPerInstallment))
                $maxInstallments--;

            while ($installmentsWithoutInterest > ($price / $minimumPerInstallment))
                $installmentsWithoutInterest--;
        }

        $interestRate = str_replace(',', '.', $this->config->get('maxipago_cc_interest_rate'));
        $interestRate = ($maxInstallments <= $installmentsWithoutInterest) ? '' : $interestRate;

        $installmentValue = $this->getInstallmentPrice($price, $maxInstallments, $interestRate);
        $totalWithoutInterest = $installmentValue;

        if ($installmentsWithoutInterest)
            $totalWithoutInterest = $price / $installmentsWithoutInterest;

        $total = $installmentValue * $maxInstallments;

        return array(
            'total' => $total,
            'installments_without_interest' => $installmentsWithoutInterest,
            'total_without_interest' => $totalWithoutInterest,
            'max_installments' => $maxInstallments,
            'installment_value' => $installmentValue,
            'interest_rate' => $interestRate,
        );
    }

    /**
     * Get ALL POSSIBLE instalments for a price
     * @param null $price
     * @return array
     */
    public function getInstallments($order_info = array())
    {
        if (! is_array($order_info))
            return false;

        $price = (float) $order_info['total'];

        $maxInstallments = $this->config->get('maxipago_cc_max_installments');//
        $installmentsWithoutInterest = $this->config->get('maxipago_cc_installments_without_interest');
        $minimumPerInstallment = $this->config->get('maxipago_cc_min_per_installments');
        $interestRate = str_replace(',', '.', $this->config->get('maxipago_cc_interest_rate'));

        if ($minimumPerInstallment > 0) {
            while ($maxInstallments > ($price / $minimumPerInstallment)) $maxInstallments--;
        }
        $installments = array();
        if ($price > 0) {
            $maxInstallments = ($maxInstallments == 0) ? 1 : $maxInstallments;
            for ($i = 1; $i <= $maxInstallments; $i++) {
                $interestRateInstallment = ($i <= $installmentsWithoutInterest) ? '' : $interestRate;
                $value = ($i <= $installmentsWithoutInterest) ? ($price / $i) : $this->getInstallmentPrice($price, $i, $interestRate);
                $total = $value * $i;

                $installments[] = array(
                    'total' => $total,
                    'total_formated' => $this->currency->format($total, $order_info['currency_code']),
                    'installments' => $i,
                    'installment_value' => $value,
                    'installment_value_formated' => $this->currency->format($value, $order_info['currency_code']),
                    'interest_rate' => $interestRateInstallment
                );
            }
        }
        return $installments;
    }

    /**
     * Get post data validating if exists
     * @param $data
     * @return null
     */
    public function getPost($data)
    {
        return isset($this->request->post[$data]) ? $this->request->post[$data] : null;
    }

    /**
     * Get post data validating if exists
     * @param $data
     * @return null
     */
    public function getRequest($data)
    {
        $data = isset($this->request->get[$data]) ? $this->request->get[$data] : null;
        if (! $data) {
            $data = isset($this->request->post[$data]) ? $this->request->post[$data] : null;
        }
        return $data;
    }

    /**
     * @param $canSave
     * @param null $customerId
     * @return array
     */
    public function getSavedCards($canSave, $customerId = null)
    {
        $saved_cards = array();
        if ($canSave && $customerId) {
            //Saved Cards
            $sql = 'SELECT *
                    FROM ' . DB_PREFIX . 'maxipago_cc_token
                    WHERE `id_customer` = \'' . $customerId . '\'';
            $saved_cards = $this->db->query($sql);
        }

        return $saved_cards;
    }

    /**
     * @param $data
     * @param int $step
     */
    public function log($data, $step = 6)
    {
        if ($this->config->get('maxipago_logging')) {
            $backtrace = debug_backtrace();
            $log = new Log('maxipago.log');
            $log->write('(' . $backtrace[$step]['class'] . '::' . $backtrace[$step]['function'] . ') - ' . $data);
        }
    }
}
